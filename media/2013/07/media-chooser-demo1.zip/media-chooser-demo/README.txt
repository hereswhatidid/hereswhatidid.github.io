=== Plugin Name ===
Contributors: hereswhatidid
Donate link: http://hereswhatidid.com/
Requires at least: 3.5.0
Tested up to: 3.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin demonstrates some basic customization of the WordPress 3.5+ Backbone Media Chooser

== Description ==

This plugin demonstrates some basic customization of the WordPress 3.5+ Backbone Media Chooser

== Installation ==

1. Upload `media-chooser-demo` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. This screen shot shows the admin interface.  It is located under Plugins -> Media Chooser Demo.  Please have your browser console open to view logged messages.

== Changelog ==

= 1.0 =
* Initial launch

== Upgrade Notice ==

= 1.0 =
Initial launch